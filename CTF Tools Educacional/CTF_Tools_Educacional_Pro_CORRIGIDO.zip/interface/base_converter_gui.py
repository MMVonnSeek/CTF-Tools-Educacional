import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import tkinter as tk
from tools.base_converter.base_converter import bin_to_dec, dec_to_bin, hex_to_dec, dec_to_hex, ascii_to_bin

def converter():
    entrada = entrada_valor.get()
    metodo = metodo_var.get()
    try:
        if metodo == "Binário → Decimal":
            resultado = bin_to_dec(entrada)
        elif metodo == "Decimal → Binário":
            resultado = dec_to_bin(int(entrada))
        elif metodo == "Decimal → Hexadecimal":
            resultado = dec_to_hex(int(entrada))
        elif metodo == "Hexadecimal → Decimal":
            resultado = hex_to_dec(entrada)
        elif metodo == "Texto → Binário":
            resultado = ascii_to_bin(entrada)
        else:
            resultado = "Método inválido"
        saida.set(str(resultado))
    except Exception as e:
        saida.set(f"Erro: {str(e)}")

janela = tk.Tk()
janela.title("Conversor de Bases")

tk.Label(janela, text="Entrada:").pack()
entrada_valor = tk.Entry(janela, width=50)
entrada_valor.pack()

metodo_var = tk.StringVar(value="Texto → Binário")
opcoes = ["Binário → Decimal", "Decimal → Binário", "Decimal → Hexadecimal", "Hexadecimal → Decimal", "Texto → Binário"]
tk.OptionMenu(janela, metodo_var, *opcoes).pack()

tk.Button(janela, text="Converter", command=converter).pack()

saida = tk.StringVar()
tk.Label(janela, textvariable=saida, fg="purple").pack()

janela.mainloop()