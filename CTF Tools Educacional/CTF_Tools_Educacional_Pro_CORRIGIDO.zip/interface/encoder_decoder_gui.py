import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import tkinter as tk
from tools.encoder_decoder.encoder_decoder import encode_base64, decode_base64, encode_url, decode_url

def codificar():
    entrada = entrada_texto.get()
    metodo = metodo_var.get()
    try:
        if metodo == "Base64":
            resultado = encode_base64(entrada)
        elif metodo == "URL":
            resultado = encode_url(entrada)
        else:
            resultado = "Método inválido"
        saida.set(resultado)
    except Exception as e:
        saida.set(f"Erro: {str(e)}")

def decodificar():
    entrada = entrada_texto.get()
    metodo = metodo_var.get()
    try:
        if metodo == "Base64":
            resultado = decode_base64(entrada)
        elif metodo == "URL":
            resultado = decode_url(entrada)
        else:
            resultado = "Método inválido"
        saida.set(resultado)
    except Exception as e:
        saida.set(f"Erro: {str(e)}")

janela = tk.Tk()
janela.title("Encoder/Decoder")

tk.Label(janela, text="Texto:").pack()
entrada_texto = tk.Entry(janela, width=50)
entrada_texto.pack()

metodo_var = tk.StringVar(value="Base64")
tk.OptionMenu(janela, metodo_var, "Base64", "URL").pack()

tk.Button(janela, text="Codificar", command=codificar).pack()
tk.Button(janela, text="Decodificar", command=decodificar).pack()

saida = tk.StringVar()
tk.Label(janela, textvariable=saida, fg="blue").pack()

janela.mainloop()