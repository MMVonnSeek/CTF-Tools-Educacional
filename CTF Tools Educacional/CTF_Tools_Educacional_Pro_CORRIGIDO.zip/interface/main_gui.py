import tkinter as tk
import importlib.util
import os

def executar_gui(nome_script):
    script_path = os.path.join(os.path.dirname(__file__), nome_script)
    spec = importlib.util.spec_from_file_location("gui_module", script_path)
    gui = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gui)

janela = tk.Tk()
janela.title("CTF Tools Educacional Pro")
janela.geometry("400x300")
tk.Label(janela, text="Selecione uma Ferramenta", font=("Arial", 14, "bold")).pack(pady=20)

botoes = {
    "Encoder/Decoder": "encoder_decoder_gui.py",
    "XOR Tool": "xor_tool_gui.py",
    "Base Converter": "base_converter_gui.py"
}

for nome, script in botoes.items():
    tk.Button(janela, text=nome, command=lambda s=script: executar_gui(s)).pack(pady=5)

janela.mainloop()