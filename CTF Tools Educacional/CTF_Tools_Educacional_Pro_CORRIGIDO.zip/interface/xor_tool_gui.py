import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import tkinter as tk
from tools.xor_tool.xor_tool import xor

def aplicar_xor():
    texto = entrada_texto.get()
    chave = entrada_chave.get()
    try:
        if not chave:
            saida.set("Erro: Chave não pode ser vazia")
            return
        resultado = xor(texto, chave)
        saida.set(resultado)
    except Exception as e:
        saida.set(f"Erro: {str(e)}")

janela = tk.Tk()
janela.title("XOR Tool")

tk.Label(janela, text="Texto:").pack()
entrada_texto = tk.Entry(janela, width=50)
entrada_texto.pack()

tk.Label(janela, text="Chave:").pack()
entrada_chave = tk.Entry(janela, width=50)
entrada_chave.pack()

tk.Button(janela, text="Aplicar XOR", command=aplicar_xor).pack()

saida = tk.StringVar()
tk.Label(janela, textvariable=saida, fg="green").pack()

janela.mainloop()