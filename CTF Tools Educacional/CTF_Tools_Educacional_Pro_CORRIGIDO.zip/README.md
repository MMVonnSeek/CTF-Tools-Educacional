# CTF Tools Educacional Pro

Execute com:
```bash
python interface/main_gui.py
```